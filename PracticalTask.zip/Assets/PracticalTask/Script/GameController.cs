using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.UI;

namespace DemoTask
{
    public class GameController : MonoBehaviour
    {
        public BlockController blockPrefab;
        public List<BlockController> allBlocks;
        public Transform blockPos;

        public GameObject inputScreen;
        public GridLayoutGroup gridLayout;
        public InputField countOfBoxInput;
        public Text warningText;

        private void Awake()
        {
            Input.multiTouchEnabled = false;  // for single touch
        }

        public void ClickOnSubmitBtn()  // submit btn
        {
            int boxCount = int.Parse(countOfBoxInput.text);
            if (boxCount <= 6 && boxCount > 1)
            {
                warningText.text = "";
                gridLayout.constraintCount = boxCount;
                GenerateBoard(boxCount);
                inputScreen.SetActive(false);
            }
            else
                warningText.text = "Please Enter Number Between 2 to 6.";
        }

        public void GenerateBoard(int countOfBox)  // Board
        {
            for (int i = 0; i < countOfBox; i++)
            {
                for (int j = 0; j < countOfBox; j++)
                {
                    BlockController block = Instantiate(blockPrefab, blockPos);
                    block.gameObject.name = i + "," + j.ToString();
                    allBlocks.Add(block);
                }
            }
        }

        public void ClickOnResetBtn()   // Reset btn
        {
            inputScreen.SetActive(true);
            for (int i = 0; i < allBlocks.Count; i++)
                Destroy(allBlocks[i].gameObject);
            allBlocks.Clear();
            countOfBoxInput.text = "";
        }
    }
}