using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.UI;

namespace DemoTask
{
    public class BlockController : MonoBehaviour
    {
        public Image cellImage;
        public RectTransform boxTrans;

        public void OnPointerEnter()
        {
            cellImage.color = Random.ColorHSV(0f, 1f, 1f, 1f, 0.5f, 1f); // assign random color
        }

        public void OnPointerExit()
        {
            cellImage.color = Color.white;
        }
    }
}